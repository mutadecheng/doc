# Usage

```
sudo docker build --tag coturn
sudo docker run -p 3478:3478 -p 3478:3478/udp coturn
```
